let dados = []

async function buscarEmpresas(){

const city = document.getElementById("city").value
const type = document.getElementById("type").value

const query = `
[out:json];
area["name"="${city}"]->.searchArea;
(
node["amenity"="${type}"](area.searchArea);
node["shop"="${type}"](area.searchArea);
node["name"~"${type}",i](area.searchArea);
);
out;
`

const url = "https://overpass-api.de/api/interpreter"

const response = await fetch(url,{
method:"POST",
body:query
})

const data = await response.json()

dados = data.elements

renderTable()
}

function renderTable(){

const tbody = document.querySelector("#resultsTable tbody")
tbody.innerHTML = ""

dados.forEach(place => {

const name = place.tags?.name || "N/A"
const phone = place.tags?.phone || "N/A"
const address = place.tags?.["addr:street"] || "N/A"

const link = `https://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lon}`

const tr = document.createElement("tr")

tr.innerHTML = `
<td>${name}</td>
<td>${address}</td>
<td>${phone}</td>
<td><a href="${link}" target="_blank">Ver</a></td>
`

tbody.appendChild(tr)

})
}

function exportCSV(){

let csv = "Nome,Endereço,Telefone,Link\n"

dados.forEach(place => {

const name = place.tags?.name || ""
const phone = place.tags?.phone || ""
const address = place.tags?.["addr:street"] || ""
const link = `https://www.openstreetmap.org/?mlat=${place.lat}&mlon=${place.lon}`

csv += `${name},${address},${phone},${link}\n`

})

const blob = new Blob([csv], {type:"text/csv"})
const url = window.URL.createObjectURL(blob)

const a = document.createElement("a")
a.href = url
a.download = "empresas.csv"
a.click()

}
